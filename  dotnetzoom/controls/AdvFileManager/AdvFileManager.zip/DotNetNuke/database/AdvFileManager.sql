/************************************************************/
/*****            Advanced File Manager 0.5b            *****/
/************************************************************/
/*                           data                           */
/************************************************************/

INSERT INTO [dbo].[ModuleDefinitions]([FriendlyName], [DesktopSrc], [Secure], [Description], [HostFee])
VALUES('Advanced File Manager','Admin/AdvFileManager/TAGFileManagerModule.ascx',1, 'Administrators can manage the files stored in their portal directories. This module allows you to upload new files, download files, delete files, rename files, create directories, delete directories, change directories, and rename directories.',.0000)
GO


/************************************************************/
/*****            Advanced File Manager 0.5b            *****/
/************************************************************/




