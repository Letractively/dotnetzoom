Imports System.ComponentModel
Imports System.Drawing.Design
Imports System.Web.UI
Imports System.Web.UI.Design
Imports System.Web.UI.WebControls

<DefaultProperty("Text"), ToolboxData("<{0}:RolloverImageButton runat=server></{0}:RolloverImageButton>")> _
Public Class RolloverImageButton
	Inherits ImageButton

	Private _enabledImageURL As String = ""
	Private _disabledImageURL As String = ""
	Private _rolloverImageURL As String = ""
	Private _statusText As String = ""

	<Bindable(True), Category("Appearance"), DefaultValue(""), EditorAttribute(GetType(System.Web.UI.Design.UrlEditor), GetType(UITypeEditor))> _
	Public Property EnabledImageURL() As String
		Get
			Return _enabledImageURL
		End Get
		Set(ByVal Value As String)
			_enabledImageURL = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue(""), EditorAttribute(GetType(System.Web.UI.Design.UrlEditor), GetType(UITypeEditor))> _
	Public Property DisabledImageURL() As String
		Get
			Return _disabledImageURL
		End Get
		Set(ByVal Value As String)
			_disabledImageURL = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue(""), EditorAttribute(GetType(System.Web.UI.Design.UrlEditor), GetType(UITypeEditor))> _
	Public Property RolloverImageURL() As String
		Get
			Return _rolloverImageURL
		End Get
		Set(ByVal Value As String)
			_rolloverImageURL = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue("")> _
	Public Property StatusText() As String
		Get
			Return _statusText
		End Get
		Set(ByVal Value As String)
			_statusText = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue("")> _
	Public Overrides Property Enabled() As Boolean
		Get
			Return MyBase.Enabled
		End Get
		Set(ByVal Value As Boolean)
			MyBase.Enabled = Value
		End Set
	End Property

	Protected Overrides Sub AddAttributesToRender(ByVal writer As System.Web.UI.HtmlTextWriter)
		If Enabled Then
			If _enabledImageURL <> "" Then
				ImageUrl = _enabledImageURL
				If _rolloverImageURL <> "" Then
					Dim OverEvent As String = ""
					Dim OutEvent As String = ""

					' mouseover javascript  
					OverEvent &= "this.src='"
					OverEvent &= ResolveUrl(_rolloverImageURL) & "'; "
					If _statusText <> "" Then
						OverEvent &= "window.status='" & _statusText & "'; "
					End If
					OverEvent &= "return true;"

					' mouseout javascript  
					OutEvent &= "this.src='"
					OutEvent &= ResolveUrl(_enabledImageURL) & "'; "
					If _statusText <> "" Then
						OutEvent &= "window.status=' '; "
					End If
					OutEvent &= "return true;"

					writer.AddAttribute("onMouseOver", OverEvent)
					writer.AddAttribute("onMouseOut", OutEvent)

				End If
			End If
		Else
			If _disabledImageURL <> "" Then
				ImageUrl = _disabledImageURL
			Else
				ImageUrl = _enabledImageURL
			End If
		End If
		MyBase.AddAttributesToRender(writer)
	End Sub

	<Browsable(False)> _
	Public Overrides Property ImageUrl() As String
		Get
			Return MyBase.ImageUrl()
		End Get
		Set(ByVal Value As String)
			MyBase.ImageUrl = Value
		End Set
	End Property
End Class
