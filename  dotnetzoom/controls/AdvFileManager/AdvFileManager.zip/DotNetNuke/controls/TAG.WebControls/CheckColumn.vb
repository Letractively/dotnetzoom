Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data

Public Class CheckBoxColumn
	Inherits System.Web.UI.WebControls.DataGridColumn

	Private _cmdName As String
	Private _postBack As Boolean = False
	Private _containingCell As TableCell

	Public Property CommandName() As String
		Get
			Return _cmdName
		End Get
		Set(ByVal Value As String)
			_cmdName = Value
		End Set
	End Property

	Public Property AutoPostBack() As Boolean
		Get
			Return _postBack
		End Get
		Set(ByVal Value As Boolean)
			_postBack = Value
		End Set
	End Property

	Public Overrides Sub InitializeCell(ByVal cell As System.Web.UI.WebControls.TableCell, ByVal columnIndex As Integer, ByVal itemType As System.Web.UI.WebControls.ListItemType)
		_containingCell = cell
		MyBase.InitializeCell(cell, columnIndex, itemType)

		Select Case itemType
			Case ListItemType.AlternatingItem, _
			  ListItemType.EditItem, _
			  ListItemType.Item, _
			  ListItemType.SelectedItem
				Dim chkBox As CheckBoxItem = New CheckBoxItem(CommandName)
				chkBox.AutoPostBack = _postBack
				cell.Controls.Add(chkBox)
		End Select
	End Sub
End Class
