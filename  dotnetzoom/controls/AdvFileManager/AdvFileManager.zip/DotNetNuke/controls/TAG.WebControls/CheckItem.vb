Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data

Public Class CheckBoxItem
	Inherits CheckBox

	Private _cmdName As String


	Private Sub CheckBoxItem_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim cmdArg As CommandEventArgs = New CommandEventArgs(_cmdName, Me.Checked)
		Dim dgArg As DataGridCommandEventArgs = _
		 New DataGridCommandEventArgs(CType(Me.Parent.NamingContainer, DataGridItem), sender, cmdArg)

		RaiseBubbleEvent(sender, dgArg)
	End Sub

	Public Sub New(ByVal cmdName As String)
		_cmdName = cmdName
		AddHandler CheckedChanged, AddressOf CheckBoxItem_CheckedChanged
	End Sub
End Class

