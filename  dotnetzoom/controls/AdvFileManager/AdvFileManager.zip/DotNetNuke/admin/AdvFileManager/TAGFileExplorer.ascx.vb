'Imports System.Drawing
Imports System.IO
Imports System.Web.UI.WebControls
Imports TAG.WebControls.AdvFileMan
'Imports MetaBuilders.WebControls

Namespace TAG.WebControls.AdvFileMan
	Public MustInherit Class TAGFileExplorer
		Inherits System.Web.UI.UserControl

		Protected WithEvents tblHeader As System.Web.UI.WebControls.Table
		Protected WithEvents lblErr As System.Web.UI.WebControls.Label
		Protected WithEvents chkSelectAll As System.Web.UI.WebControls.CheckBox
		Protected WithEvents FileManData As TAG.WebControls.AdvFileMan.FileManagerData
		Protected WithEvents grdFileFolders As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
			Me.FileManData = New TAG.WebControls.AdvFileMan.FileManagerData()
			CType(Me.FileManData, System.ComponentModel.ISupportInitialize).BeginInit()
			'
			'FileManData
			'
			Me.FileManData.DataSetName = "FileManagerData"
			Me.FileManData.Locale = New System.Globalization.CultureInfo("en-US")
			Me.FileManData.Namespace = "http://tempuri.org/FileManagerData.xsd"
			CType(Me.FileManData, System.ComponentModel.ISupportInitialize).EndInit()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

#Region " Constants "
		Private extensions() As String = { _
		 ".arj", ".asa", ".asax", ".ascx", ".asmx", ".asp", ".aspx", ".au", _
		 ".avi", ".bat", ".bmp", ".cab", ".chm", ".com", ".config", ".cs", _
		 ".css", ".disco", ".dll", ".doc", ".exe", ".gif", ".hlp", ".htm", _
		 ".html", ".jpg", ".inc", ".ini", ".log", ".mdb", ".mid", ".midi", _
		 ".mov", ".mp3", ".mpg", ".mpeg", ".pdf", ".ppt", ".sys", ".txt", _
		 ".tif", ".vb", ".vbs", ".vsdisco", ".wav", ".wri", ".xls", ".xml", _
		 ".zip"}
		Private textExtensions() As String = { _
		 ".asa", ".asax", ".ascx", ".asmx", ".asp", ".aspx", ".bat", _
		 ".config", ".cs", ".css", ".disco", ".htm", ".html", ".inc", _
		 ".ini", ".log", ".sys", ".txt", ".vb", ".vbs", ".vsdisco", _
		 ".xls", ".xml"}

		'Private Const CheckColumn As Integer = 0
		'Private Const IconColumn As Integer = 1
		'Private Const NameColumn As Integer = 2
		'Private Const TypeColumn As Integer = 3
		'Private Const ScrollBarColumn As Integer = 7

		Private Enum GridColumn
			ColumnCheck
			ColumnIcon
			ColumnName
			ColumnType
			ColumnSize
			ColumnCreate
			ColumnModify
			ColumnScroll
		End Enum
#End Region

#Region " Public Events "

		Public Event DirChanged As DirChangedEventHandler

		Protected Overridable Sub OnDirChanged(ByVal e As DirChangedEventArgs)
			RaiseEvent DirChanged(Me, e)
		End Sub

		Public Event FileClicked As FileClickedEventHandler

		Protected Overridable Sub OnFileClicked(ByVal e As FileClickedEventArgs)
			RaiseEvent FileClicked(Me, e)
		End Sub

		Public Event CheckClicked As CheckClickedEventHandler

		Protected Overridable Sub OnCheckClicked(ByVal e As CheckClickedEventArgs)
			RaiseEvent CheckClicked(Me, e)
		End Sub

#End Region

#Region " Public Properties "
		Public Property Root() As String
			Get
				Return Me.ViewState("RootDir")
			End Get
			Set(ByVal Value As String)
				If Me.ViewState("RootDir") <> Value Then
					Dim _Root As String
					If Value.IndexOf(":") <> -1 Then
						_Root = Value
					Else
						_Root = Server.MapPath(Value)
					End If
					If Right(_Root, 1) = "\" Then
						_Root = Left(_Root, _Root.Length - 1)
					End If
					Me.ViewState("RootDir") = _Root
					Session("RootDir") = _Root
					BindData()
					Dim e As New DirChangedEventArgs(_Root, RelativeDir)
					OnDirChanged(e)
				End If
			End Set
		End Property

		Public Property RelativeDir() As String
			Get
				Return Me.ViewState("RelativeDir")
			End Get
			Set(ByVal Value As String)
				If Me.ViewState("RelativeDir") <> Value Then
					Me.ViewState("RelativeDir") = Value
					Session("RelativeDir") = Value
					BindData()
					Dim e As New DirChangedEventArgs(Root, Value)
					OnDirChanged(e)
				End If
			End Set
		End Property

		Public Property AllowRecursiveDelete() As Boolean
			Get
				Return Me.ViewState("RecursiveDelete")
			End Get
			Set(ByVal Value As Boolean)
				Me.ViewState("RecursiveDelete") = Value
			End Set
		End Property

		Public Property RoundTripOnCheck() As Boolean
			Get
				Return Me.ViewState("RoundTripOnCheck")
			End Get
			Set(ByVal Value As Boolean)
				Me.ViewState("RoundTripOnCheck") = Value
			End Set
		End Property
#End Region

#Region " Public Methods "
		Public Sub NavigateParentDir()
			Dim RelDir As String = RelativeDir
			If RelDir <> "" Then
				RelativeDir = Left(RelDir, InStrRev(RelDir, "\") - 1)
			End If
		End Sub

		Public Sub Refresh()
			BindData()
		End Sub

		Public Sub DeleteSelected()
			Try
				Dim grdItem As DataGridItem
				For Each grdItem In grdFileFolders.Items
					Dim chkItem As CheckBoxItem = GetCheckSelect(grdItem)
					If chkItem.Checked = True Then
						Dim FName As String = GetNameLinkButton(grdItem).Text()
						If IsDirectory(grdItem) Then
							Directory.Delete(Root & RelativeDir & "\" & FName, AllowRecursiveDelete)
						Else
							File.Delete(Root & RelativeDir & "\" & FName)
						End If
					End If
				Next
			Catch e As Exception
				lblErr.Text = e.Message
				lblErr.Visible = True
			End Try
			'Refresh Grid
			BindData()
		End Sub

		Public Sub DownloadFile()
			Try
				Dim grdItem As DataGridItem
				For Each grdItem In grdFileFolders.Items
					Dim chkItem As CheckBoxItem = GetCheckSelect(grdItem)
					If chkItem.Checked = True Then
						Dim FName As String = GetNameLinkButton(grdItem).Text()
						If IsFile(grdItem) Then
							Response.Redirect(ResolveUrl("TAGFileDownload.aspx") & "?File=" & Root & RelativeDir & "\" & FName)
							chkItem.Checked = False
							Exit For
						End If
					End If
				Next
			Catch e As Exception
				lblErr.Text = e.Message
				lblErr.Visible = True
			End Try
		End Sub

		Public Function SelectedCount() As Integer
			Dim i As Integer
			Dim grdItem As DataGridItem
			For Each grdItem In grdFileFolders.Items
				If GetCheckSelect(grdItem).Checked Then
					i += 1
				End If
			Next
			Return i
		End Function

		Public Sub EditFileFolderName()
			Try
				Dim grdItem As DataGridItem
				For Each grdItem In grdFileFolders.Items
					If GetCheckSelect(grdItem).Checked = True Then
						grdFileFolders.EditItemIndex = grdItem.ItemIndex
						BindData()
						Exit For
					End If
				Next
			Catch e As Exception
				lblErr.Text = e.Message
				lblErr.Visible = True
			End Try
		End Sub

		Public Sub CreateNewFolder()
			Try
				Dim di As New DirectoryInfo(Root & RelativeDir)

				Dim NewDirBase As String = "New Directory"
				Dim i As Integer = 0
				Dim NewDir As String
				NewDir = NewDirBase
				While DirectoryExists(di, NewDir)
					NewDir = String.Format("{0} ({1})", NewDirBase, i)
				End While
				di.CreateSubdirectory(NewDir)
				FillData()
				Dim ndx As Integer = FindDataNameItem(NewDir)
				If ndx > -1 Then
					grdFileFolders.EditItemIndex = ndx
					grdFileFolders.DataSource = New DataView(FileManData.Tables("FileFolder"))
					grdFileFolders.DataBind()
				End If
			Catch e As Exception
				lblErr.Text = e.Message
				lblErr.Visible = True
			End Try
		End Sub
#End Region

#Region " Constituent Events "
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			'Put user code to initialize the page here
			If Not Page.IsPostBack Then
				If Root = "" Then
					Root = Request.ApplicationPath.ToString
				End If
			End If
		End Sub

		Private Sub grdFileFolders_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdFileFolders.ItemDataBound
			If (e.Item.ItemType = ListItemType.Item) Or (e.Item.ItemType = ListItemType.AlternatingItem) Or (e.Item.ItemType = ListItemType.SelectedItem) Or (e.Item.ItemType = ListItemType.EditItem) Then
				Dim img As Image = GetImageIcon(e.Item)
				'Dim lnk As HyperLink = CType(e.Item.FindControl("lnkName"), HyperLink)
				With FileManData.Tables("FileFolder").Rows(e.Item.DataSetIndex)
					If .Item("RowType") = "Dir" Then
						img.ImageUrl = "images/closedfolder.gif"
						'lnk.NavigateUrl = String.Format(NavigateURL, lnk.ClientID)
					Else
						Dim extIndex As Integer = Array.IndexOf(extensions, .Item("Type"))
						If extIndex > -1 Then
							img.ImageUrl = "images/" & CType(.Item("Type"), String).Substring(1) & ".gif"
						Else
							img.ImageUrl = "images/unknown.gif"
						End If
					End If
					If e.Item.ItemType = ListItemType.EditItem Then
						GetImageOK(e.Item).CommandArgument = .Item("Name")
					End If
				End With
			End If
		End Sub

		Private Sub grdFileFolders_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdFileFolders.ItemCommand
			Select Case e.CommandName
				Case "CheckClick"
					Dim lnk As LinkButton = GetNameLinkButton(e.Item)
					Dim evt As New CheckClickedEventArgs(Root & RelativeDir & "\" & lnk.Text(), CType(e.CommandSource, CheckBoxItem), SelectedCount)
					OnCheckClicked(evt)
				Case "Select"
					' If this is a directory then goto new directory
					If IsDirectory(e.Item) Then
						RelativeDir += "\" & CType(e.CommandSource, LinkButton).Text()
					Else					  ' If this is a file - will open file
						Dim evt As New FileClickedEventArgs(Root, RelativeDir, CType(e.CommandSource, LinkButton).Text())
						OnFileClicked(evt)
					End If
				Case "EditOK"
					RenameFileFolder(e.Item.ItemIndex, e.CommandArgument, GetRenameTextBox(e.Item).Text)
					grdFileFolders.EditItemIndex = -1
					BindData()
				Case "EditCancel"
					grdFileFolders.EditItemIndex = -1
					BindData()
			End Select
		End Sub

		Private Sub chkSelectAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSelectAll.CheckedChanged
			Dim grdItem As DataGridItem
			For Each grdItem In grdFileFolders.Items
				CType(grdItem.Cells(0).Controls(0), CheckBoxItem).Checked = chkSelectAll.Checked
			Next
		End Sub
#End Region

#Region " Private Methods "
		Private Sub BindData()
			FillData()
			grdFileFolders.DataSource = New DataView(FileManData.Tables("FileFolder"))
			grdFileFolders.DataBind()
		End Sub

		Private Sub FillData()
			Dim CurrentDir As DirectoryInfo
			Dim ChildDirs As DirectoryInfo()
			Dim ChildDir As DirectoryInfo
			Dim ChildFiles As FileInfo()
			Dim ChildFile As FileInfo
			Dim dr As DataRow
			Dim DefaultSortIndex As Integer = 0

			Try
				If RelativeDir = "" Then
					CurrentDir = New DirectoryInfo(Root)
				Else
					CurrentDir = New DirectoryInfo(Root & RelativeDir)
				End If
				ChildDirs = CurrentDir.GetDirectories
				ChildFiles = CurrentDir.GetFiles

				For Each ChildDir In ChildDirs
					dr = FileManData.Tables("FileFolder").NewRow
					dr("Name") = ChildDir.Name
					dr("Size") = FormatSize(GetDirSize(ChildDir))
					dr("CreateDate") = ChildDir.CreationTime
					dr("ModifyDate") = ChildDir.LastWriteTime
					dr("RowType") = "Dir"
					dr("DefaultSortIndex") = DefaultSortIndex
					DefaultSortIndex += 1
					FileManData.Tables("FileFolder").Rows.Add(dr)
				Next
				For Each ChildFile In ChildFiles
					dr = FileManData.Tables("FileFolder").NewRow
					dr("Name") = ChildFile.Name
					dr("Type") = ChildFile.Extension
					dr("Size") = FormatSize(ChildFile.Length)
					dr("CreateDate") = ChildFile.CreationTime
					dr("ModifyDate") = ChildFile.LastWriteTime
					dr("RowType") = "File"
					dr("DefaultSortIndex") = DefaultSortIndex
					DefaultSortIndex += 1
					FileManData.Tables("FileFolder").Rows.Add(dr)
				Next
				If DefaultSortIndex < 13 Then
					tblHeader.Rows(0).Cells(GridColumn.ColumnScroll).BackColor = System.Drawing.Color.Transparent
				Else
					tblHeader.Rows(0).Cells(GridColumn.ColumnScroll).BackColor = System.Drawing.Color.Silver
				End If
			Catch e As Exception
				lblErr.Text() = e.Message
				lblErr.Visible = True
			End Try
			'DataFormatString="{0:MM/dd/yy hh:mm tt}"
		End Sub

		Private Function FormatSize(ByVal Size As Long) As String
			If Size < 1024 Then
				Return String.Format("{0:N0} B", Size)
			ElseIf (Size < 1048576) Then
				Return String.Format("{0:N2} KB", Size / 1024)
			Else
				Return String.Format("{0:N2} MB", Size / (1048576))
			End If
		End Function

		Private Function GetDirSize(ByVal CurDir As DirectoryInfo) As Long
			Dim dirSize As Long
			Dim theFile As FileInfo

			Dim subDir As DirectoryInfo
			For Each subDir In CurDir.GetDirectories
				dirSize += GetDirSize(subDir)
			Next
			For Each theFile In CurDir.GetFiles
				dirSize += theFile.Length
			Next
			Return dirSize
		End Function

		Private Function IsDirectory(ByVal Item As DataGridItem) As Boolean
			If CType(Item.Cells(GridColumn.ColumnType).Controls(1), Label).Text = "" Then
				Return True
			Else
				Return False
			End If
		End Function

		Private Function IsFile(ByVal Item As DataGridItem) As Boolean
			If IsDirectory(Item) Then
				Return False
			Else
				Return True
			End If
		End Function

		Private Function GetNameLinkButton(ByVal item As DataGridItem) As LinkButton
			Return CType(item.FindControl("lnkNameColumn"), LinkButton)
		End Function

		Private Function GetCheckSelect(ByVal item As DataGridItem) As CheckBoxItem
			Return CType(item.Cells(GridColumn.ColumnCheck).Controls(0), CheckBoxItem)
		End Function

		Private Function GetImageIcon(ByVal item As DataGridItem) As Image
			Return CType(item.Cells(GridColumn.ColumnIcon).Controls(1), Image)
		End Function

		Private Function GetImageOK(ByVal item As DataGridItem) As RolloverImageButton
			Return CType(item.FindControl("imgEditOK"), RolloverImageButton)
		End Function

		Private Function GetRenameTextBox(ByVal item As DataGridItem) As TextBox
			Return CType(item.FindControl("txtRename"), TextBox)
		End Function

		Private Sub RenameFileFolder(ByVal ItemIndex As Integer, ByVal oldName As String, ByVal newName As String)
			Try
				Dim grdItem As DataGridItem = grdFileFolders.Items(ItemIndex)
				If IsDirectory(grdItem) Then
					Dim di As DirectoryInfo = New DirectoryInfo(GetFullName(oldName))
					di.MoveTo(GetFullName(newName))
				Else
					Dim fi As FileInfo = New FileInfo(GetFullName(oldName))
					fi.MoveTo(GetFullName(newName))
				End If
			Catch e As Exception
				lblErr.Text = e.Message
				lblErr.Visible = True
			End Try
		End Sub

		Private Function GetFullName(ByVal Name As String) As String
			Return Root & RelativeDir & "\" & Name
		End Function

		Private Function DirectoryExists(ByVal DirInfo As DirectoryInfo, ByVal DirName As String) As Boolean
			Dim di As DirectoryInfo
			For Each di In DirInfo.GetDirectories
				If UCase(di.Name) = UCase(DirName) Then
					Return True
				End If
			Next
			Return False
		End Function

		Private Function FindDataNameItem(ByVal Name As String) As Integer
			Dim dr As DataRow
			Dim i As Integer = 0
			For Each dr In FileManData.Tables("FileFolder").Rows
				If dr("Name") = Name Then
					Return i
				End If
				i += 1
			Next
			Return -1
		End Function

		' this method is called when user clicks on any of the column headings
		Sub SortFileFolders(ByVal sender As Object, ByVal e As DataGridSortCommandEventArgs)
			'Dim SortExprs() As String
			'Dim CurrentSearchMode As String
			'Dim NewSearchMode As String
			'Dim ColumnToSort As String
			'Dim NewSortExpr As String

			''  Parse the sort expression - delimiter space
			'SortExprs = Split(e.SortExpression, " ")
			'ColumnToSort = SortExprs(0)

			'' If a sort order is specified get it, else default is descending
			'If SortExprs.Length() > 1 Then
			'    CurrentSearchMode = SortExprs(1).ToUpper()
			'    If CurrentSearchMode = "ASC" Then
			'        NewSearchMode = "Desc"
			'    Else
			'        NewSearchMode = "Asc"
			'    End If
			'Else   ' If no mode specified, Default is descending
			'    NewSearchMode = "Desc"
			'End If

			''  Derive the new sort expression. 
			'NewSortExpr = ColumnToSort & " " & NewSearchMode

			'' Figure out the column index 
			'Dim iIndex As Integer
			'Select Case ColumnToSort.ToUpper()
			'    Case "DEFAULTSORTINDEX"
			'        iIndex = 0
			'    Case "NAME"
			'        iIndex = 1
			'    Case "TYPE"
			'        iIndex = 3
			'    Case "SIZE"
			'        iIndex = 4
			'    Case "CREATEDATE"
			'        iIndex = 5
			'    Case "MODIFYDATE"
			'        iIndex = 6
			'End Select

			'' alter the column's sort expression 
			'grdFileFolders.Columns(iIndex).SortExpression = NewSortExpr
			'Dim i As Integer
			'For i = 0 To grdFileFolders.Columns.Count - 1
			'    If i = iIndex Then
			'        grdFileFolders.Columns(i).HeaderImageUrl = "./images/" & NewSearchMode & ".gif"
			'    Else
			'        grdFileFolders.Columns(i).HeaderImageUrl = "./images/blank.gif"
			'    End If
			'Next

			'' Sort the data in new order
			'FillData()
			'Dim dv As DataView = New DataView(FileManData.Tables("FileFolder"))
			'dv.Sort = NewSortExpr
			'grdFileFolders.DataSource = dv
			'grdFileFolders.DataBind()
		End Sub
#End Region
	End Class
End Namespace