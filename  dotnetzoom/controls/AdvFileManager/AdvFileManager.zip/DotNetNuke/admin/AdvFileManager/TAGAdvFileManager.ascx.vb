Imports System.IO
Imports TAG.WebControls.AdvFileMan

Namespace TAG.WebControls.AdvFileMan
	Public MustInherit Class TAGAdvFileManager
		Inherits System.Web.UI.UserControl

		Protected WithEvents pnlToolBar As System.Web.UI.WebControls.Panel
		Protected WithEvents Image1 As System.Web.UI.WebControls.Image
		Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
		Protected WithEvents Table1 As System.Web.UI.WebControls.Table
		Protected WithEvents FileExp As TAGFileExplorer
		Protected WithEvents Image2 As System.Web.UI.WebControls.Image
		Protected WithEvents Image3 As System.Web.UI.WebControls.Image
		Protected WithEvents RolloverImageButton1 As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgRefresh As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgNewFolder As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgUpload As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgDownload As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgDelete As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgRename As TAG.WebControls.RolloverImageButton
		Protected WithEvents imgParentDir As TAG.WebControls.RolloverImageButton

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			'Put user code to initialize the page here
			Dim incScript As String = String.Format("<script Language=""javascript"" SRC=""{0}""></script>", ResolveUrl("dialog.js"))
			Page.RegisterClientScriptBlock("FileManager", incScript)


			Dim retScript As String = "<script language=""javascript"">" & vbCrLf & "<!--" & vbCrLf
			retScript &= "function retVal()" & vbCrLf & "{" & vbCrLf
			retScript &= vbTab & Page.GetPostBackEventReference(imgRefresh) & ";" & vbCrLf & "}" & vbCrLf
			retScript &= "--></script>"
			Page.RegisterClientScriptBlock("FileManagerRefresh", retScript)

			imgDelete.Attributes.Add("onClick", "JavaScript:return confirm('Do you want to delete the selected folder(s) and/or file(s)?');")

			' This only worked for IE...  May reinstitute it in dialog.js
			'imgUpload.Attributes.Add("onclick", "window.showModalDialog('FileUploadDialog.aspx', null,'dialogWidth:370px;dialogHeight:150px;dialogHide:true;status:no;help:no;scroll:no');")

			Dim click As String = String.Format("openDialog('{0}', 500, 150, retVal);return false", ResolveUrl("TAGFileUploadDialog.aspx"), imgRefresh.ClientID)
			imgUpload.Attributes.Add("onclick", click)


			InitToolbar()
		End Sub

		Private Sub InitToolbar()
			Dim selCount As Integer = FileExp.SelectedCount
			Select Case selCount
				Case 0
					imgDownload.Enabled = False
					imgRename.Enabled = False
					imgDelete.Enabled = False
				Case 1
					imgDownload.Enabled = True
					imgDelete.Enabled = True
					imgRename.Enabled = True
				Case Else
					imgDownload.Enabled = False
					imgRename.Enabled = False
			End Select
		End Sub

		Private Sub imgParentDir_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgParentDir.Click
			FileExp.NavigateParentDir()
		End Sub

		Private Sub FileExp_DirChanged(ByVal sender As Object, ByVal e As TAG.WebControls.AdvFileMan.DirChangedEventArgs) Handles FileExp.DirChanged
			If e.IsRoot Then
				imgParentDir.Enabled = False
			Else
				imgParentDir.Enabled = True
			End If
		End Sub

		Private Sub FileExp_FileClicked(ByVal sender As Object, ByVal e As TAG.WebControls.AdvFileMan.FileClickedEventArgs) Handles FileExp.FileClicked
			lblMessage.Text = e.FullFileName
		End Sub

		Private Sub imgRefresh_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRefresh.Click
			FileExp.Refresh()
		End Sub

		Private Sub imgDelete_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgDelete.Click
			FileExp.DeleteSelected()
		End Sub

		Private Sub imgDownload_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgDownload.Click
			FileExp.DownloadFile()
		End Sub

		Private Sub imgRename_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRename.Click
			FileExp.EditFileFolderName()
		End Sub

		Private Sub imgNewFolder_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgNewFolder.Click
			FileExp.CreateNewFolder()
		End Sub
	End Class
End Namespace
