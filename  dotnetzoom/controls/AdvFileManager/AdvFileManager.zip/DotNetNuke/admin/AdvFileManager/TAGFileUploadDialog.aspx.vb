Namespace TAG.WebControls.AdvFileMan
	Public Class TAGFileUploadDialog
		Inherits System.Web.UI.Page
		Protected WithEvents Table1 As System.Web.UI.WebControls.Table
		Protected WithEvents Label1 As System.Web.UI.WebControls.Label
		Protected WithEvents btnUpload As System.Web.UI.WebControls.Button
		Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
		Protected WithEvents htmlUploadFile As System.Web.UI.HtmlControls.HtmlInputFile

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			'Put user code to initialize the page here
			btnCancel.Attributes.Add("onclick", "handleCancel();")
		End Sub

		Private Sub btnUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpload.Click
			Dim strFileName As String
			Dim strFileNamePath As String

			'If ((((objAdmin.GetPortalSpaceUsed(PortalId) + htmlUploadFile.PostedFile.ContentLength) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (TabId = _portalSettings.SuperTabId) Then

			'Gets the file name
			strFileName = System.IO.Path.GetFileName(htmlUploadFile.PostedFile.FileName)

			strFileNamePath = Session("RootDir") & Session("RelativeDir") & "\" & strFileName

			'Save Uploaded file to server
			htmlUploadFile.PostedFile.SaveAs(strFileNamePath)

			'End If


			RegisterClientScriptBlock("ClientScript", "<Script language=""JavaScript"">handleOK()</Script>")
		End Sub
	End Class
End Namespace
