Author: 	Joe Brinkman
Biography:	Computer engineer with broad IT background including Network Engineering, Software Engineering and mangement.
More Info:	http://www.theaccidentalgeek.com
Abstract:	Advanced File Manageer

Module Description:

This module is designed to allow you to maintain files and folders on your portal.  This beta release  includes:
  Directory
  ---------
  -change directory
  -delete directory/directories
  -create directory
  -rename directory

    Files
  ---------
  -upload file
  -download file
  -delete file/files
  -rename file


Upcoming releases will focus on bug fixes, documentation, converting user controls to web controls and adding additional functionality including:
  -Creating text based files
  -Editing text files
  -Moving files/directories
  -configure root directory
